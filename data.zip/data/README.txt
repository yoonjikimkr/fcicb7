AmpliFinancials 가상 운영 데이터
========================================

[users] 20,000 rows
  - user_id                   object
  - signup_date               datetime64[ns]
  - utm_source                object
  - country                   object
  - home_currency             object
  - age                       int64
  - income_bucket             object
  - platform                  object
  - activity                  float64
  - kyc_completed             bool
  - kyc_completed_at          datetime64[ns]

[events] 55,529 rows
  - user_id                   object
  - event_name                object
  - event_time                datetime64[ns]

[transactions] 11,446 rows
  - txn_id                    object
  - user_id                   object
  - txn_time                  datetime64[ns]
  - txn_type                  object
  - amount                    float64
  - currency                  object
  - usd_amount                float64
  - fee_usd                   float64

[fx_exchanges] 2,450 rows
  - fx_id                     object
  - user_id                   object
  - fx_time                   datetime64[ns]
  - from_currency             object
  - to_currency               object
  - amount_from               float64
  - amount_to                 float64
  - market_rate               float64
  - applied_rate              float64
  - spread_usd                float64

[trades] 3,001 rows
  - trade_id                  object
  - user_id                   object
  - trade_time                datetime64[ns]
  - symbol                    object
  - side                      object
  - quantity                  int64
  - price                     float64
  - gross_usd                 float64
  - commission_usd            float64

[subscriptions] 1,378 rows
  - sub_id                    object
  - user_id                   object
  - plan                      object
  - billing_date              datetime64[ns]
  - mrr_usd                   float64

[referrals] 655 rows
  - referral_id               object
  - inviter_user_id           object
  - invitee_user_id           object
  - offered_at                datetime64[ns]
  - converted_at              datetime64[ns]

